import cv2

# 打开摄像头
cap = cv2.VideoCapture(0)  # 0 表示默认摄像头

if not cap.isOpened():
    print("无法打开摄像头")
    exit()

while True:
    ret, frame = cap.read()
    if not ret:
        print("无法获取帧")
        break

    # 显示帧
    cv2.imshow('Frame', frame)

    # 按 'q' 退出
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 释放摄像头
cap.release()
cv2.destroyAllWindows()